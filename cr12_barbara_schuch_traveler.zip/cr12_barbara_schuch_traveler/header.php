<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_Barbara_Schuch_traveler
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<div id="page" class="site">
		<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'cr12_barbara_schuch_traveler' ); ?></a>

		<header id="masthead" class="site-header container-fluid">

			<?php if (is_front_page() && (has_header_image() )) { ?>
				<div id="headerimage" class="img" style="background-image: url(<?php header_image(); ?>);"></div>
			<?php } ?>

			<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
				<div class="site-branding d-flex align-items-center">
							<?php
							the_custom_logo();
							if ( is_front_page() && is_home() ) :
								?>
								<h1 class="site-title"><a class="navbar-brand ml-4" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
								<?php
							else :
								?>
								<p class="site-title"><a class="navbar-brand ml-4" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
								<?php
							endif;
								?>

				</div><!-- .site-branding -->

				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<!-- <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarNavDropdown"> -->
				<?php

				wp_nav_menu( array(
					'theme_location'    => 'primary',
					'depth'             => 2, // 1 = no dropdowns, 2 = dropdown
					'container'         => 'div',
					'container_class'   => 'collapse navbar-collapse d-flex justify-content-end',
					'container_id'      => 'navbarNavDropdown',
					'menu_class'        => 'nav navbar-nav',
					'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
					'walker'            => new WP_Bootstrap_Navwalker(),
				) );

				?>

				</div>
			</nav>
			
			<?php
				if ( is_front_page() && is_home() ) :
				$cr12_barbara_schuch_traveler_description = get_bloginfo( 'description', 'display' );
			?>
				<h1 class="site-description text-center p-4 uppercase"><?php echo $cr12_barbara_schuch_traveler_description; /* WPCS: xss ok. */ ?></h1>
			<?php endif; ?>

		</header><!-- #masthead -->

<div id="content" class="site-content container-fluid">
